const karticky = document.querySelectorAll(".karticka")

// karticky[0].classList.remove("otocena")

const otocKartu = (event) => {
    event.target.classList.toggle("otocena")
}
 
karticky.forEach((card) => {
    card.addEventListener("click", otocKartu)
})
