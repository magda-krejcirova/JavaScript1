# Pexeso

Postupujte podle zadání cvičení [Pexeso](https://kodim.cz/kurzy/daweb/js1/cykly/cv-foreach#cvlekce%3Epexeso).
